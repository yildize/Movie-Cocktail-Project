import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RequestsService {

  

  constructor(private http: HttpClient) {
  }

  
  sendMovies(){
    const post = {target: "mat", max: 5};
    this.http.post('https://my-api-demo.herokuapp.com/search', post).subscribe({
      next: (response) => {
        console.log(response);
      }
    });
  }


/*
sendMovies(){
  this.http.post("https://my-api-demo.herokuapp.com/search",{target:"mat",max:5}).toPromise().then((data:any) => {
    console.log(data);
  })
}
*/

}
