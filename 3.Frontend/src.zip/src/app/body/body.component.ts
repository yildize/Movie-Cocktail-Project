import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

  //Movie lists:
  moviesList: string[] = []; //Movies that showed on the search result, changes on every search operation.
  ingredients: string[] = []; //List of selected movies to be combined.
  //Booleans for visibility operations.
  isListHidden = true;
  isShakerHidden = true;
  bDis = true;
  notFound = false;
  isSearching = false;
  isShaking = false;
  //Variables for slider operations
  sliderValues = {};
  sliderValuesCalc = {}; //ratios
  keys = [];
  values = [];
  sum = 0;
  //Cocktail Information
  cocktailInfo = {}
  isShaked = false;
  recMovies: string [] = [];
  avgDistFromCocktail: number;
  avgDistsOfRecMovies2Cocktail: number [] = [];
  avgDistsOfRecMovies2Others: number [] = [];

  currentRecMovieId = 0;
  recNum = 10; //number of recommendations.

  showDist = 0;
  showInfo = false;

  constructor( private http: HttpClient) {}

  ngOnInit(): void {}

  //Add selected movie tot he ingredients 
  selectMovie(movie: string): void{
    this.isListHidden = true;
    this.moviesList = [];
    if (!this.ingredients.includes(movie)){
      this.ingredients.push(movie);
    }
    this.isShakerHidden = false;

    //Don't forget the slider operations:
    this.sliderValuesCalc[movie] = 0;
    this.bDis = true;
    this.reset();
    this.refresh();
  }

  //Searches the input movie by sending a request
  onSearch(form): void{
    var targetMovie = form.value["searchedMov"].toLowerCase( ) //User input movie to be searched.
    var maxElements = 20 //Max elements showed on the search results.
    //Send request to the API:
    this.searchRequest(targetMovie,maxElements)
    this.isShakerHidden = true;
    this.isShaked = false;
  }

  //Removes the selected movie from the ingredients
  onClear(movie): void{
    this.ingredients = this.ingredients.filter(obj => obj !== movie);
    delete this.sliderValues[movie];
    delete this.sliderValuesCalc[movie];
    this.refresh();

    if( this.ingredients.length === 0){
      this.isShakerHidden = true;
    }

  }

  //Set ratios when slider values changed
  onSliderChange(val, mov): void{
    // Add current movie-sliderValue to the dict:
    this.sliderValues[mov] = Number(val);
    this.refresh();
  }

  //Refresh slider values:
  refresh(){
    this.sum = 0;
    // Get the sum of the slider values:
    this.values = Object.values(this.sliderValues);
    this.values.forEach(element => {
      this.sum += element;
    });

    if( this.sum > 0){
      this.bDis = false;
    }

    // Calculate overall percentage of each movie and add to the sliderValuesCalc:
    Object.keys(this.sliderValues).forEach(key => {
      if (this.sum === 0){
        this.sliderValuesCalc[key] = 0;
      }
      else{
        var num = this.sliderValues[key]/this.sum
        //this.sliderValuesCalc[key] = Math.round(this.sliderValues[key]/this.sum*100);
        this.sliderValuesCalc[key] = Math.round((num + Number.EPSILON) * 100) / 100
      }
    });
  }

  //Reset slider values:
  reset(): void{
    Object.keys(this.sliderValues).forEach(key => {
        this.sliderValues[key] = 0;
    });
  }

  
  onShake(){
    this.isShaked = false;
    var ratios = []
    this.ingredients.forEach(mov => {
      ratios.push(this.sliderValuesCalc[mov])
    });
    this.mixRequest(this.ingredients, ratios, this.recNum);

    this.currentRecMovieId = 0;
    this.showDist = 0;

  }
  

  //Send a search request using the given keyword, at most maxEl search results will be returned.
  searchRequest(keyword:string, maxEl: number){
    this.isSearching = true;
    const post = {target: keyword, max: maxEl};
    this.http.post('https://my-api-demo.herokuapp.com/search', post).subscribe({
      next: (response) => {
        //API response will be 
        this.moviesList = response["message"];
        if (this.moviesList.length == 0){
          this.notFound = true;
          this.isListHidden = true;
        }else {
          this.notFound = false;
          this.isListHidden = false;
        }
        this.isSearching = false;
      }
    });
  }

  mixRequest(movies:string [], ratioList: number [], num: number){
    this.isShaking = true;
    const post = {selectedMovies: movies, ratios: ratioList, numRec: num};
    this.http.post('https://my-api-demo.herokuapp.com/mix', post).subscribe({
      next: (response) => {
        //API response will be 
        this.recMovies = response["recMovies"];
        this.avgDistFromCocktail = response["avgDistFromCocktail"];
        this.avgDistsOfRecMovies2Cocktail = response["avgDistsOfRecMovies2Cocktail"]
        this.avgDistsOfRecMovies2Others = response["avgDistsOfRecMovies2Others"];

        //Wait 2 seconds for shake animation
        var ms = 2000
        var start = new Date().getTime();
        var end = start;
        while(end < start + ms) {
          end = new Date().getTime();
        }
        
        this.isShaked = true;
        this.isShaking = false;
      }
    });
  }

  goBack(){
    this.isShaked = false;
  }

  searchOnGoogle(movie:string){
    var url = 'https://www.google.com/search?q=' + encodeURIComponent(movie);
    window.open(url,"_blank")
  }

  onNext(){
    this.currentRecMovieId = (this.currentRecMovieId+1)%(this.recNum);
  }

  onPrev(){
    if(this.currentRecMovieId == 0 ){
      this.currentRecMovieId = this.recNum-1;
    }
    else{
      this.currentRecMovieId = (this.currentRecMovieId-1);
    }
  }

  moreRec(){
    this.recNum = 20;
    this.onShake();
  }



}
